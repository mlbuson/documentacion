
document.addEventListener('DOMContentLoaded', () => {
  console.log('git-auto.js cargado');
});
